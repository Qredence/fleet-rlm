# Insert into the existing test_daytona_adapter.py after _FakeBackend.
@pytest.mark.parametrize("failure_source", ["backend", "stdout"])
def test_backend_type_error_never_replays_execution(failure_source: str) -> None:
    from fleet_rlm.daytona.interpreter import DaytonaCodeInterpreter

    failure = TypeError("failure after the action already started")
    calls: list[str] = []

    class StreamingBackend(_FakeBackend):
        def run(self, code, variables=None, *, on_stdout=None):
            assert code == "action"
            assert variables == {"value": 1}
            calls.append(code)
            if failure_source == "backend":
                raise failure
            if on_stdout is not None:
                on_stdout("partial output")
            return "done"

    def output(value: str) -> None:
        assert value == "partial output"
        raise failure

    interpreter = DaytonaCodeInterpreter(backend=StreamingBackend())
    with pytest.raises(TypeError) as raised:
        interpreter._run_backend("action", {"value": 1}, on_stdout=output)
    assert raised.value is failure
    assert calls == ["action"]


@pytest.mark.parametrize("shape", ["legacy", "streaming", "variadic"])
def test_backend_dispatch_selects_call_shape_before_execution(shape: str) -> None:
    from fleet_rlm.daytona.interpreter import DaytonaCodeInterpreter

    calls: list[tuple[str, object]] = []
    chunks: list[str] = []

    class LegacyBackend(_FakeBackend):
        def run(self, code, variables=None):
            calls.append((code, variables))
            return "done"

    class StreamingBackend(_FakeBackend):
        def run(self, code, variables=None, *, on_stdout=None):
            calls.append((code, variables))
            assert on_stdout is not None
            on_stdout("chunk")
            return "done"

    class VariadicBackend(_FakeBackend):
        def run(self, code, variables=None, **kwargs):
            calls.append((code, variables))
            kwargs["on_stdout"]("chunk")
            return "done"

    backends = {"legacy": LegacyBackend, "streaming": StreamingBackend, "variadic": VariadicBackend}
    interpreter = DaytonaCodeInterpreter(backend=backends[shape]())
    result = interpreter._run_backend("action", {"value": 1}, on_stdout=chunks.append)
    assert result == "done"
    assert calls == [("action", {"value": 1})]
    assert chunks == ([] if shape == "legacy" else ["chunk"])


def test_backend_dispatch_rejects_incompatible_shape_without_execution() -> None:
    from fleet_rlm.daytona.interpreter import DaytonaCodeInterpreter

    calls: list[str] = []

    class IncompatibleBackend(_FakeBackend):
        def run(self, code, variables, required, *, on_stdout=None):
            del variables, required, on_stdout
            calls.append(code)
            return "done"

    interpreter = DaytonaCodeInterpreter(backend=IncompatibleBackend())
    with pytest.raises(TypeError):
        interpreter._run_backend("action", None, on_stdout=lambda _value: None)
    assert calls == []


@pytest.mark.parametrize(
    ("recoverable", "expected"),
    [(True, "Execution error"), (False, "Execution failed")],
)
def test_public_output_distinguishes_execution_and_interpreter_errors(recoverable: bool, expected: str) -> None:
    from dspy.primitives.code_interpreter import CodeExecutionError, CodeInterpreterError

    from fleet_rlm.daytona.interpreter import DaytonaCodeInterpreter

    error_type = CodeExecutionError if recoverable else CodeInterpreterError
    interpreter = DaytonaCodeInterpreter()
    assert interpreter._public_output(error_type("private error details")) == expected



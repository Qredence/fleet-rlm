# Complete replacement methods; class members, not a standalone module.
    def _public_output(self, result: Any) -> str:
        if is_final_output(result):
            return PUBLIC_FINAL_OUTPUT_LABEL
        if isinstance(result, CodeExecutionError):
            return "Execution error"
        if isinstance(result, CodeInterpreterError):
            return "Execution failed"
        return truncate_public_text(str(result or ""), max_len=self._observation_max_chars)

    def _run_backend(
        self,
        code: str,
        variables: dict[str, Any] | None,
        *,
        on_stdout: OutputCallback,
    ) -> str | BackendExecutionResult:
        backend = self._backend
        if backend is None:
            raise DaytonaAdapterError(
                message="interpreter backend is not configured", cause_type="InterpreterConfigurationError"
            )
        run = cast(Callable[..., str | BackendExecutionResult], backend.run)
        # Select the legacy call shape before executing anything. A TypeError
        # from backend code or an output callback must never replay the action.
        signature = inspect.signature(run)
        try:
            signature.bind(code, variables, on_stdout=on_stdout)
        except TypeError:
            signature.bind(code, variables)
            return run(code, variables)
        return run(code, variables, on_stdout=on_stdout)


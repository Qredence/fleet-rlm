"""Run only the changed methods, NOT Fleet's full dependency/runtime stack.

This isolated harness compiles the reviewed or patched method bodies unchanged
into a minimal adapter. It supplies explicit stand-ins for the surrounding
Fleet constructor and DSPy errors. The error inheritance is copied from DSPy
3.4.0. It runs the same eight new regression cases supplied in the patch.

Usage:
    python validate_isolated.py              # patched methods
    python validate_isolated.py --baseline   # expected: three failing cases

No network, SDK, model, or sandbox is used. Passing this script is not a Fleet
integration result and does not certify that the patch is production-ready.
"""
from __future__ import annotations

import inspect
import sys
from collections.abc import Callable
from pathlib import Path
from types import ModuleType
from typing import Any, cast

import pytest

ROOT = Path(__file__).resolve().parent


def main() -> int:
    baseline = "--baseline" in sys.argv[1:]
    methods = (ROOT / ("reviewed-methods.txt" if baseline else "replacement-methods.py")).read_text()
    # Remove the human-readable file header, not any method implementation.
    if methods.startswith("#"):
        methods = methods.split("\n", 1)[1]

    class CodeInterpreterError(RuntimeError):
        """Stand-in with the relevant verified DSPy inheritance."""

    class CodeExecutionError(CodeInterpreterError):
        """Recoverable subclass, matching DSPy 3.4.0."""

    class DaytonaAdapterError(RuntimeError):
        def __init__(self, *, message: str, cause_type: str) -> None:
            super().__init__(message)
            self.cause_type = cause_type

    def unused(*_args: Any, **_kwargs: Any) -> Any:
        raise AssertionError("isolated test reached an unstubbed integration boundary")

    namespace = {
        "__name__": "isolated_adapter",
        "Any": Any,
        "Callable": Callable,
        "cast": cast,
        "inspect": inspect,
        "CodeInterpreterError": CodeInterpreterError,
        "CodeExecutionError": CodeExecutionError,
        "DaytonaAdapterError": DaytonaAdapterError,
        "BackendExecutionResult": object,
        "OutputCallback": Callable[[str], None],
        "is_final_output": lambda _value: False,
        "PUBLIC_FINAL_OUTPUT_LABEL": "FINAL submitted",
        "truncate_public_text": unused,
    }
    constructor = (
        "class DaytonaCodeInterpreter:\n"
        "    def __init__(self, *, backend=None):\n"
        "        self._backend = backend\n"
        "        self._observation_max_chars = 10000\n\n"
    )
    exec(compile(constructor + methods, "reviewed_adapter_methods", "exec"), namespace)

    fake_modules = {}
    for name in (
        "dspy", "dspy.primitives", "dspy.primitives.code_interpreter",
        "fleet_rlm", "fleet_rlm.daytona", "fleet_rlm.daytona.interpreter",
    ):
        module = ModuleType(name)
        module.__path__ = []
        fake_modules[name] = module
    fake_modules["dspy.primitives.code_interpreter"].CodeInterpreterError = CodeInterpreterError
    fake_modules["dspy.primitives.code_interpreter"].CodeExecutionError = CodeExecutionError
    fake_modules["fleet_rlm.daytona.interpreter"].DaytonaCodeInterpreter = namespace["DaytonaCodeInterpreter"]
    sys.modules.update(fake_modules)

    import tempfile

    with tempfile.TemporaryDirectory(prefix="fleet-isolated-") as directory:
        test_file = Path(directory) / "test_method_regressions.py"
        # New tests override run(); they do not use any other _FakeBackend
        # behavior. Retaining an empty base explicitly limits the tested scope.
        test_file.write_text(
            "import pytest\n\nclass _FakeBackend:\n    pass\n\n"
            + (ROOT / "regression-tests.py").read_text()
        )
        label = "baseline" if baseline else "patched"
        print(f"ISOLATED METHOD CHECKS ONLY: {label}; no Fleet/DSPy/Daytona integration")
        return pytest.main(["-q", "-c", "/dev/null", "--override-ini", "addopts=", str(test_file)])


if __name__ == "__main__":
    raise SystemExit(main())
